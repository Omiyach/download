はじめに
このパックのダークモード部分の元となる「Dark Mode」リソースパックを作ってくださったOffroaders123様に感謝申し上げます。
(Dark Mode: https://mcpedl.com/dark-mode-resource-pack/)

利用規約
このリソースパックは公開サーバーでご自由にご使用いただけます。
もし仮に改変したものを配布する場合は、ご自由にしてもらって構いませんが、公開した場所のリンクを僕のTwitter(最後にリンク有)に送ってくださると喜びます。

説明
このリソースパックは、ダウンロード・インストールの軽量化のために変更のあるテクスチャのみpngファイルを入れています。
もし、ご自身で画像を追加したいなら https://github.com/Mojang/bedrock-samples/releases から最新の大元のリソースパックをダウンロードしてください。
また、おかしなテクスチャが出た場合やその他不具合がありましたらTwitter(最後にリンク有)にご連絡ください。

おわりに
それではこのリソースパックをお楽しみください！
最後までお読みいただきありがとうございました。

連絡先
Twitter: @omiyachannel
YouTube: @omiyachannel
Website: omiyachannel.wixsite.com/site
Mail: omachannelmail@gmail.com

2023/07/22